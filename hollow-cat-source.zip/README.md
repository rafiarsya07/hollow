# HOLLOW — Two Travelers (Dark / Cinematic Edition)

A long, hardcore, atmospheric 2D platformer — LIMBO-flavoured storytelling, a
clickable lantern in a dark hollow world, full mobile controls, and a complete arc.

## Story (told LIMBO-style)
The game opens on a black screen with fading lines: a world that lost its light to a
three-form shadow; a man waking alone in the dark; something small waiting in the
grass. He meets a cat in **The Meadow** and they travel together through **The Snow
Pass**, the haunted **Autumn Wood**, **The Oasis**, down into **The Deep**, and finally
up to **The Void** to break the shadow and return the light. Most of the story is told
without words — through the dark, the sounds (ghost moans, falling trees), and what you
see, not what you're told.

## Two ways to play
1. **hollow-cat.html** — single file, double-click. Everything embedded.
2. **hollow-cat-src/** — source. ES modules need a local server:
   `python3 -m http.server 8000` -> http://localhost:8000

## What's new in this edition
- **Cinematic prologue** — fading narrative lines before World I (click / any key / auto-advance).
- **Adaptive fullscreen viewport** — fills any window/phone aspect (no more letterbox cutoff).
- **Fixed falling-tree logic** — the tree topples RIGHT and the crush zone is on the
  right to match; safe on the left, then jump the fallen log (now a solid obstacle).
- **Fixed pink-blob prop** — foliage props are correctly green now.
- **Richer UI/UX** — lantern + pause quick-buttons, full pause settings (music, SFX,
  lantern darkness, touch controls, screen shake), quit-to-menu.

## Lighting (the "hollow" feel)
The world is dark. A warm lantern lights a pool around you; orbs, lit levers and the
exit glow through the black. Toggle with **F** or the top-right button.

## Controls
Move <- -> / A D · Jump (double!) Space/W/Up · Run Shift · Drop-through Down/S ·
Lever E · Lantern F · Restart R · Pause P · Stomp enemies from above.
Mobile: on-screen D-pad, run, action, big jump; auto-shown on touch + toggle in Pause.

## Worlds (6) & mechanics
I Meadow · II Snow Pass · III Autumn Wood · IV Oasis · V The Deep · Finale: The Void (3-form boss).
Crumbling ledges, fake floors, invisible blocks, spike tunnels, falling spike blocks,
falling trees, cannons, rhythm blocks, toggle gates, conveyors, springs, wind, diving
bats, roaming monsters, moving platforms, checkpoints, light orbs, gauntlet finales.

## Structure
index.html · css/style.css ·
js/{main,assets,audio,lighting,input,camera,segments,levels,parallax,world,player}.js
