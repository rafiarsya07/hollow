// player.js — character physics, collision, sprite animation. Skin = 'broo' | 'cat'.

import { IMG, SPRITE } from './assets.js';
import { Input, consumeJump } from './input.js';
import { playSfx } from './audio.js';

const GRAVITY=2000, MOVE=240, RUN=400, JUMP_V=640, MAX_FALL=1150, COYOTE=0.10;

export class Player {
  constructor(skin='broo'){
    this.skin=skin;
    this.w=30; this.h= skin==='cat'?34:44;
    this.reset(0,0);
  }
  setSkin(skin){ this.skin=skin; this.h= skin==='cat'?34:44; }
  reset(x,y){
    this.x=x; this.y=y; this.vx=0; this.vy=0;
    this.grounded=false; this.faceR=true; this.coy=0; this.jumps=0;
    this.alive=true; this.anim='idle'; this.animTime=0; this.frame=0; this.squash=1;
    this.onMover=null;
  }
  _key(name){
    // returns sprite key for skin+anim
    if(this.skin==='cat'){
      if(name==='run')return 'cat_run'; if(name==='walk')return 'cat_walk'; return 'cat_idle';
    }
    if(name==='run'||name==='walk')return 'broo_run';
    if(name==='jump')return 'broo_jump';
    if(name==='fall')return 'broo_fall';
    return 'broo_idle';
  }

  update(dt, solids){
    if(!this.alive) return;
    const speed=Input.run?RUN:MOVE;
    if(Input.left){this.vx=-speed;this.faceR=false;}
    else if(Input.right){this.vx=speed;this.faceR=true;}
    else this.vx*=0.78;

    if(this.grounded){this.coy=COYOTE;this.jumps=0;}
    else this.coy=Math.max(0,this.coy-dt);

    if(consumeJump()){
      if(this.coy>0||this.grounded){this.vy=-JUMP_V;this.grounded=false;this.coy=0;this.jumps=1;this.squash=0.7;playSfx('jump',0.5);}
      else if(this.jumps<2){this.vy=-JUMP_V*0.85;this.jumps=2;this.squash=0.72;playSfx('jump',0.4);}
    }

    this.vy+=GRAVITY*dt;
    if(this.vy>MAX_FALL)this.vy=MAX_FALL;

    this._sweep(dt,solids);
    this.squash+=(1-this.squash)*Math.min(1,dt*12);

    // animation state
    let st='idle';
    if(!this.grounded) st=this.vy<0?'jump':'fall';
    else if(Math.abs(this.vx)>40) st=Input.run?'run':'walk';
    if(st!==this.anim){this.anim=st;this.animTime=0;this.frame=0;}
    const sp=SPRITE[this._key(st)];
    this.animTime+=dt;
    if(sp.frames>1){const fd=1/sp.fps; while(this.animTime>=fd){this.animTime-=fd;this.frame=(this.frame+1)%sp.frames;}}
    else this.frame=0;
  }

  _sweep(dt,solids){
    let nx=this.x+this.vx*dt;
    for(const s of solids){
      if(nx<s.x+s.w&&nx+this.w>s.x&&this.y+3<s.y+s.h&&this.y+this.h-3>s.y){
        if(this.vx>0)nx=s.x-this.w; else if(this.vx<0)nx=s.x+s.w;
        this.vx=0; break;
      }
    }
    this.x=nx;
    let ny=this.y+this.vy*dt; this.grounded=false; this.onMover=null;
    for(const s of solids){
      if(this.x<s.x+s.w&&this.x+this.w>s.x&&ny<s.y+s.h&&ny+this.h>s.y){
        if(this.vy>0){ny=s.y-this.h;this.grounded=true;if(this.vy>800)this.squash=0.7;if(s.ref)this.onMover=s.ref;}
        else ny=s.y+s.h;
        this.vy=0; break;
      }
    }
    this.y=ny;
    if(this.onMover&&this.onMover.axis==='x') this.x+=this.onMover._dx||0;
  }

  draw(ctx){
    if(!this.alive) return;
    const sp=SPRITE[this._key(this.anim)];
    const img=IMG[sp.img]; if(!img) return;
    const drawH= this.skin==='cat'?52:60;
    const drawW=drawH*(sp.fw/sp.fh);
    const cx=this.x+this.w/2, by=this.y+this.h;
    const sx=this.frame*sp.fw;
    ctx.save();
    ctx.translate(cx,by);
    const sq=this.squash, stx=1+(1-sq)*0.6;
    ctx.scale((this.faceR?1:-1)*stx,sq);
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(img,sx,0,sp.fw,sp.fh,-drawW/2,-drawH+2,drawW,drawH);
    ctx.restore();
  }
}
