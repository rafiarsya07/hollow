// assets.js — preloads images + audio, exposes by key, reports progress

const MANIFEST = {
  broo_idle:'assets/sprites/broo_idle.png',broo_run:'assets/sprites/broo_run.png',
  broo_jump:'assets/sprites/broo_jump.png',broo_fall:'assets/sprites/broo_fall.png',
  cat_idle:'assets/sprites/cat_idle.png',cat_walk:'assets/sprites/cat_walk.png',cat_run:'assets/sprites/cat_run.png',
  bat:'assets/sprites/bat.png',explosion:'assets/sprites/explosion.png',
  en_goblin:'assets/sprites/enemy_goblin.png',en_wolf:'assets/sprites/enemy_wolf.png',
  en_ghost:'assets/sprites/enemy_ghost.png',en_scorpion:'assets/sprites/enemy_scorpion.png',
  en_lizard:'assets/sprites/enemy_lizard.png',en_snake:'assets/sprites/enemy_snake.png',
  en_dragon:'assets/sprites/enemy_dragon.png',en_rat:'assets/sprites/enemy_rat.png',
  en_cockatrice:'assets/sprites/enemy_cockatrice.png',
  boss1:'assets/sprites/boss_1.png',boss2:'assets/sprites/boss_2.png',boss3:'assets/sprites/boss_3.png',
  potion_red:'assets/sprites/potion_red.png',potion_blue:'assets/sprites/potion_blue.png',
  prop_tree:'assets/props/tree.png',prop_bush:'assets/props/bush.png',prop_rock:'assets/props/rock.png',
  prop_mushroom:'assets/props/mushroomRed.png',prop_fern:'assets/props/fern.png',
  prop_shrub:'assets/props/shrub.png',prop_cactus:'assets/props/cactus.png',
  prop_gem:'assets/props/gemBlue.png',prop_star:'assets/props/star.png',
  // parallax backdrops (each theme: _2 far jpg + _1 near png)
  meadow_far:'assets/pbg/meadow_2.jpg',meadow_near:'assets/pbg/meadow_1.png',
  snow_far:'assets/pbg/snow_2.jpg',snow_near:'assets/pbg/snow_1.png',
  autumn_far:'assets/pbg/autumn_2.jpg',autumn_near:'assets/pbg/autumn_1.png',
  desert_far:'assets/pbg/desert_2.jpg',desert_near:'assets/pbg/desert_1.png',
  dungeon_far:'assets/pbg/dungeon_2.jpg',dungeon_near:'assets/pbg/dungeon_1.png',
  redwood_far:'assets/pbg/redwood_2.jpg',redwood_near:'assets/pbg/redwood_1.png',
  // space pack
  space_bg:'assets/space/bg.png',space_stars:'assets/space/stars.png',
  space_far:'assets/space/far.png',space_big:'assets/space/big.png',space_ring:'assets/space/ring.png',
};

const AUDIO_MANIFEST = {
  jump:'assets/audio/jump.mp3',click:'assets/audio/click.mp3',collect:'assets/audio/collect.mp3',
  lever:'assets/audio/lever.mp3',hit:'assets/audio/hit.mp3',door:'assets/audio/door.mp3',
  m_menu:'assets/audio/m_menu.mp3',m_forest:'assets/audio/m_forest.mp3',m_cave:'assets/audio/m_cave.mp3',
  m_dungeon:'assets/audio/m_dungeon.mp3',m_swamp:'assets/audio/m_swamp.mp3',
  m_space:'assets/audio/m_space.mp3',m_boss:'assets/audio/m_boss.mp3',
  treefall:'assets/audio/treefall.mp3',ghost:'assets/audio/ghost.mp3',
  amb_dark:'assets/audio/amb_dark.mp3',heartbeat:'assets/audio/heartbeat.mp3',step:'assets/audio/step.mp3',
};

export const IMG={}; export const SND={};

export function loadAssets(onProgress){
  const ik=Object.keys(MANIFEST), ak=Object.keys(AUDIO_MANIFEST);
  const total=ik.length+ak.length; let done=0;
  const tick=()=>{done++;onProgress&&onProgress(done/total);};
  const ip=ik.map(k=>new Promise(res=>{const im=new Image();im.onload=()=>{IMG[k]=im;tick();res();};im.onerror=()=>{IMG[k]=null;tick();res();};im.src=MANIFEST[k];}));
  const ap=ak.map(k=>new Promise(res=>{const a=new Audio();a.preload='auto';a.oncanplaythrough=()=>{if(!SND[k]){SND[k]=a;tick();}res();};a.onerror=()=>{SND[k]=null;tick();res();};a.src=AUDIO_MANIFEST[k];setTimeout(()=>{if(!SND[k]){SND[k]=a;tick();}res();},1500);}));
  return Promise.all([...ip,...ap]);
}

export const SPRITE={
  broo_idle:{img:'broo_idle',fw:46,fh:50,frames:1,fps:1},
  broo_run:{img:'broo_run',fw:46,fh:50,frames:8,fps:14},
  broo_jump:{img:'broo_jump',fw:46,fh:50,frames:1,fps:1},
  broo_fall:{img:'broo_fall',fw:46,fh:50,frames:1,fps:1},
  cat_idle:{img:'cat_idle',fw:72,fh:60,frames:1,fps:1},
  cat_walk:{img:'cat_walk',fw:72,fh:60,frames:6,fps:10},
  cat_run:{img:'cat_run',fw:80,fh:68,frames:6,fps:15},
  bat:{img:'bat',fw:32,fh:32,frames:6,fps:12},
};
