// world.js — draws level geometry + all hazards + entities

import { IMG, SPRITE } from './assets.js';

const GROUND={
  meadow:{top:'#3a5a2e',body:'#1c2e16',edge:'#4d7038'},
  mountain:{top:'#4a4f5e',body:'#22262f',edge:'#5d6478'},
  autumn:{top:'#6b3320',body:'#321810',edge:'#8a4628'},
  desert:{top:'#b8893f',body:'#5e441d',edge:'#d4a458'},
  dungeon:{top:'#3a4450',body:'#171c24',edge:'#4d5a68'},
};

function plat(ctx,g,p){
  ctx.fillStyle=g.body;ctx.fillRect(p.x,p.y,p.w,p.h);
  ctx.fillStyle=g.top;ctx.fillRect(p.x,p.y,p.w,8);
  ctx.fillStyle=g.edge;ctx.fillRect(p.x,p.y,p.w,2);
  ctx.fillStyle='rgba(0,0,0,0.15)';
  for(let y=p.y+20;y<p.y+p.h;y+=24)ctx.fillRect(p.x,y,p.w,2);
}
function spikes(ctx,x,y,w,scale=1){
  const n=Math.floor(w/12),h=16*scale;
  for(let i=0;i<n;i++){const bx=x+i*12;
    ctx.fillStyle='#cdd2dc';ctx.beginPath();ctx.moveTo(bx,y+h);ctx.lineTo(bx+6,y);ctx.lineTo(bx+12,y+h);ctx.closePath();ctx.fill();
    ctx.fillStyle='rgba(0,0,0,0.25)';ctx.beginPath();ctx.moveTo(bx+6,y);ctx.lineTo(bx+12,y+h);ctx.lineTo(bx+7,y+h);ctx.closePath();ctx.fill();}
}

export function drawWorld(ctx,lv,st,ts){
  const g=GROUND[lv.theme]||GROUND.meadow;

  for(const p of lv.platforms) plat(ctx,g,p);

  // decorative props (drawn behind player, on the ground)
  for(const p of (st.props||[])){
    const img=IMG[p.sprite];if(!img)continue;
    const sc=p.sprite==='prop_tree'?1.4:0.8;
    const dw=img.width*sc,dh=img.height*sc;
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(img,p.x-dw/2,p.y-dh,dw,dh);
  }

  // falling trees (pivot at base, topples to the RIGHT across the path)
  for(const t of (st.treefalls||[])){
    const img=IMG.prop_tree;if(!img)continue;
    const dw=img.width*1.5,dh=img.height*1.5;
    ctx.save();
    ctx.translate(t.x,t.y);              // pivot at trunk base on the ground
    if(t._fallen||t._falling){
      ctx.rotate(Math.min(Math.PI/2*0.9,(t._ang||0)));  // clockwise = falls right
    }
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(img,-dw*0.32,-dh,dw,dh);   // trunk base near pivot
    ctx.restore();
  }


  // conveyors (animated arrows)
  for(const c of (st.conveyors||[])){
    ctx.fillStyle=g.edge;ctx.fillRect(c.x,c.y,c.w,c.h);
    ctx.fillStyle='rgba(255,255,255,0.25)';
    const off=(ts*0.06*c.dir)% 20;
    for(let x=c.x+((off+20)%20);x<c.x+c.w;x+=20){
      ctx.beginPath();
      if(c.dir>0){ctx.moveTo(x,c.y+3);ctx.lineTo(x+6,c.y+c.h/2);ctx.lineTo(x,c.y+c.h-3);}
      else{ctx.moveTo(x+6,c.y+3);ctx.lineTo(x,c.y+c.h/2);ctx.lineTo(x+6,c.y+c.h-3);}
      ctx.fill();
    }
  }

  // one-way
  for(const o of (st.oneWay||[])){
    ctx.fillStyle=g.edge;ctx.fillRect(o.x,o.y,o.w,10);
    ctx.fillStyle=g.top;ctx.fillRect(o.x,o.y,o.w,3);
    ctx.fillStyle='rgba(255,255,255,0.12)';
    for(let x=o.x+4;x<o.x+o.w;x+=10)ctx.fillRect(x,o.y+11,5,2);
  }

  // toggle blocks (solid when gate's lever active)
  for(const t of (st.toggleBlocks||[])){
    const on=t._solid;
    ctx.globalAlpha=on?1:0.25;
    ctx.fillStyle=on?'#6aa0e0':'#40506a';
    ctx.fillRect(t.x,t.y,t.w,t.h);
    ctx.strokeStyle='rgba(180,210,255,0.6)';ctx.lineWidth=1;ctx.strokeRect(t.x+.5,t.y+.5,t.w-1,t.h-1);
    ctx.globalAlpha=1;
  }

  // disappearing rhythm blocks
  for(const d of (st.disappearing||[])){
    if(d._vis<=0.05) continue;
    ctx.globalAlpha=d._vis;
    ctx.fillStyle=g.edge;ctx.fillRect(d.x,d.y,d.w,16);
    ctx.fillStyle=g.top;ctx.fillRect(d.x,d.y,d.w,3);
    ctx.globalAlpha=1;
  }

  // fake platforms — look identical to real ground until touched
  for(const f of (st.fakePlat||[])){
    if(f._fell) continue;
    const wob=f._wobble?Math.sin(ts*0.05)*1.5:0;
    ctx.save();ctx.translate(0,wob);
    ctx.fillStyle=g.edge;ctx.fillRect(f.x,f.y,f.w,f.h||20);
    ctx.fillStyle=g.top;ctx.fillRect(f.x,f.y,f.w,3);
    ctx.restore();
  }

  // crumble
  for(const c of (st.crumble||[])){
    if(c.gone)continue;
    const sh=c.triggered?(Math.random()-0.5)*2.4:0;
    ctx.save();ctx.translate(sh,0);
    ctx.fillStyle=c.triggered?'#8a6a44':g.edge;ctx.fillRect(c.x,c.y,c.w,16);
    ctx.fillStyle=g.top;ctx.fillRect(c.x,c.y,c.w,3);
    ctx.strokeStyle='rgba(0,0,0,0.5)';ctx.lineWidth=1;ctx.beginPath();
    ctx.moveTo(c.x+c.w*0.3,c.y);ctx.lineTo(c.x+c.w*0.4,c.y+16);
    ctx.moveTo(c.x+c.w*0.65,c.y);ctx.lineTo(c.x+c.w*0.55,c.y+16);ctx.stroke();
    ctx.restore();
  }

  // springs
  for(const s of (st.springs||[])){
    const c=s._fire?6:0;
    ctx.fillStyle='#caa23a';ctx.fillRect(s.x,s.y-c,s.w,8+c);
    ctx.fillStyle='#e8c468';ctx.fillRect(s.x+4,s.y-4-c,s.w-8,4);
  }

  // movers
  for(const m of (st.movers||[])){
    ctx.fillStyle=g.edge;ctx.fillRect(m.x,m.y,m.w,m.h);
    ctx.fillStyle=g.top;ctx.fillRect(m.x,m.y,m.w,4);
    ctx.strokeStyle='rgba(255,255,255,0.2)';ctx.lineWidth=1;ctx.strokeRect(m.x+.5,m.y+.5,m.w-1,m.h-1);
  }

  // gates
  for(const gt of (st.gates||[])){
    if(gt.open)continue;
    ctx.fillStyle='rgba(40,44,60,0.92)';ctx.fillRect(gt.x,gt.y,gt.w,gt.h);
    ctx.strokeStyle='rgba(120,130,170,0.5)';ctx.lineWidth=1.5;ctx.strokeRect(gt.x+.5,gt.y+.5,gt.w-1,gt.h-1);
    for(let y=gt.y+8;y<gt.y+gt.h;y+=14){ctx.fillStyle='rgba(0,0,0,0.3)';ctx.fillRect(gt.x,y,gt.w,3);}
  }

  // levers
  for(const lv2 of (st.levers||[])){
    ctx.fillStyle='#2a2a38';ctx.fillRect(lv2.x-9,lv2.y,18,10);
    const a=lv2.active?-0.6:0.6;
    ctx.strokeStyle=lv2.active?'#e8c468':'#7a7488';ctx.lineWidth=4;ctx.lineCap='round';
    if(lv2.active){ctx.shadowColor='rgba(232,196,104,0.7)';ctx.shadowBlur=12;}
    ctx.beginPath();ctx.moveTo(lv2.x,lv2.y+5);ctx.lineTo(lv2.x+Math.sin(a)*18,lv2.y+5-Math.cos(a)*18);ctx.stroke();
    ctx.fillStyle=lv2.active?'#f0d080':'#8a849a';
    ctx.beginPath();ctx.arc(lv2.x+Math.sin(a)*18,lv2.y+5-Math.cos(a)*18,5,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  }

  // cannons + projectiles
  for(const c of (st.cannons||[])){
    ctx.fillStyle='#3a3a48';ctx.fillRect(c.x-6,c.y-9,18,18);
    ctx.fillStyle='#22222c';ctx.fillRect(c.x+(c.dir<0?-12:6),c.y-5,10,10);
  }
  for(const p of (st.projectiles||[])){
    ctx.fillStyle='#e87a4a';ctx.shadowColor='rgba(232,122,74,0.8)';ctx.shadowBlur=8;
    ctx.beginPath();ctx.arc(p.x,p.y,6,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  }

  // wind zones (visual streaks)
  for(const w of (st.windZones||[])){
    ctx.save();ctx.globalAlpha=0.10;ctx.strokeStyle='#bfe0ff';ctx.lineWidth=2;
    const off=(ts*0.2*(w.fx<0?-1:1))%40;
    for(let y=w.y+10;y<w.y+w.h;y+=22){
      const sx=w.x+((off+40)%40);
      ctx.beginPath();ctx.moveTo(sx,y);ctx.lineTo(sx+(w.fx<0?-24:24),y);ctx.stroke();
    }
    ctx.restore();
  }

  // falling spike blocks
  for(const fsx of (st.fallSpikes||[])){
    ctx.fillStyle='#9aa0ac';ctx.fillRect(fsx.x,fsx.y,fsx.w,18);
    spikes(ctx,fsx.x,fsx.y+18,fsx.w,1);
  }

  // invisible blocks (only drawn faintly once revealed)
  for(const iv of (st.invisible||[])){
    if(!iv._shown)continue;
    ctx.fillStyle='rgba(232,196,104,0.85)';ctx.fillRect(iv.x,iv.y,iv.w,iv.h);
    ctx.strokeStyle='#fff';ctx.lineWidth=1;ctx.strokeRect(iv.x+.5,iv.y+.5,iv.w-1,iv.h-1);
    ctx.fillStyle='#7a5a20';ctx.font='12px serif';ctx.textAlign='center';ctx.fillText('?',iv.x+iv.w/2,iv.y+13);
  }

  // static spikes
  for(const sp of (lv.spikes||[])) spikes(ctx,sp.x,sp.y,sp.w,1);
  // timed spikes
  for(const sp of (st.spikeTimer||[])){
    const out=sp._out??1;
    if(out>0.02) spikes(ctx,sp.x,sp.y+(1-out)*16,sp.w,out);
    ctx.fillStyle='rgba(60,60,70,0.6)';ctx.fillRect(sp.x,sp.y+14,sp.w,3);
  }

  // bats
  const bf=Math.floor(ts/80)%SPRITE.bat.frames;
  for(const b of (st.bats||[])){
    const img=IMG.bat;if(!img)continue;
    ctx.save();ctx.translate(b.x,b.y);if(b.vx<0)ctx.scale(-1,1);
    ctx.imageSmoothingEnabled=false;ctx.drawImage(img,bf*32,0,32,32,-14,-14,28,28);ctx.restore();
  }


  // ground/ghost enemies
  for(const e of (st.enemies||[])){
    if(e.dead)continue;
    const img=IMG[e.sprite];if(!img)continue;
    const dh = e.type==='ghost'?40:46;
    const dw = dh*(img.width/img.height);
    ctx.save();ctx.translate(e.x,e.y);
    if(e.type==='ghost'){ctx.globalAlpha=0.85;}
    if(e.vx>0)ctx.scale(-1,1);
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(img,-dw/2,-dh+2,dw,dh);
    ctx.restore();ctx.globalAlpha=1;
  }

  // boss
  if(st.boss&&!st.boss.dead){
    const b=st.boss;const key='boss'+b.form;const img=IMG[key];
    if(img){
      const dh=150,dw=dh*(img.width/img.height);
      ctx.save();ctx.translate(b.x,b.y);
      // hover bob
      ctx.translate(0,Math.sin(ts*0.002)*6);
      if(b.castT>0){ctx.shadowColor='rgba(180,60,220,0.8)';ctx.shadowBlur=24;}
      ctx.imageSmoothingEnabled=false;
      ctx.drawImage(img,-dw/2,-dh,dw,dh);
      ctx.restore();ctx.shadowBlur=0;
      // hp bar
      ctx.fillStyle='rgba(0,0,0,0.5)';ctx.fillRect(b.x-60,b.y-dh-18,120,8);
      ctx.fillStyle='#d04a6a';ctx.fillRect(b.x-58,b.y-dh-16,116*(b.hp/b.maxhp),4);
    }
  }
  // boss projectiles (orbs of shadow)
  for(const p of (st.bossShots||[])){
    ctx.fillStyle='#b84ad8';ctx.shadowColor='rgba(184,74,216,0.9)';ctx.shadowBlur=12;
    ctx.beginPath();ctx.arc(p.x,p.y,8,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  }

  // orbs
  const pulse=0.5+0.5*Math.sin(ts*0.004);
  for(const o of (st.orbs||[])){
    if(o.taken)continue;
    const fy=o.y+Math.sin(ts*0.003+o.x*0.01)*5;
    ctx.shadowColor='rgba(232,196,104,0.9)';ctx.shadowBlur=18+pulse*12;
    ctx.globalAlpha=0.55+pulse*0.3;ctx.fillStyle='#f4dc90';
    ctx.beginPath();ctx.arc(o.x,fy,7+pulse*2,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=0.15;ctx.beginPath();ctx.arc(o.x,fy,18+pulse*6,0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=1;ctx.shadowBlur=0;
  }

  // checkpoints
  for(const cp of (st.checkpoints||[])){
    ctx.strokeStyle=cp.reached?'#e8c468':'rgba(180,180,200,0.5)';ctx.lineWidth=3;
    ctx.beginPath();ctx.moveTo(cp.x,cp.y);ctx.lineTo(cp.x,cp.y-34);ctx.stroke();
    ctx.fillStyle=cp.reached?'#e8c468':'rgba(150,150,170,0.5)';
    if(cp.reached){ctx.shadowColor='rgba(232,196,104,0.7)';ctx.shadowBlur=10;}
    ctx.beginPath();ctx.moveTo(cp.x,cp.y-34);ctx.lineTo(cp.x+18,cp.y-28);ctx.lineTo(cp.x,cp.y-22);ctx.closePath();ctx.fill();
    ctx.shadowBlur=0;
  }

  // exit
  const ex=lv.exit;
  if(ex){
  const ep=0.5+0.5*Math.sin(ts*0.003);
  const grad=ctx.createLinearGradient(ex.x,ex.y,ex.x,ex.y+ex.h);
  grad.addColorStop(0,'rgba(127,212,232,0)');grad.addColorStop(0.5,`rgba(127,212,232,${0.5+ep*0.3})`);grad.addColorStop(1,'rgba(127,212,232,0)');
  ctx.shadowColor='rgba(127,212,232,0.8)';ctx.shadowBlur=20+ep*14;ctx.fillStyle=grad;ctx.fillRect(ex.x,ex.y,ex.w,ex.h);ctx.shadowBlur=0;
  ctx.strokeStyle=`rgba(180,235,250,${0.5+ep*0.3})`;ctx.lineWidth=2;ctx.strokeRect(ex.x+.5,ex.y+.5,ex.w-1,ex.h-1);
  }
}

export function drawPartner(ctx,cat,ts){
  if(!cat.active)return;
  const sp=Math.abs(cat.vx)>30?SPRITE.cat_walk:SPRITE.cat_idle;
  const img=IMG[sp.img];if(!img)return;
  const fr=sp.frames>1?Math.floor(ts/100)%sp.frames:0;
  const dh=42,dw=dh*(sp.fw/sp.fh);
  ctx.save();ctx.translate(cat.x,cat.y+cat.h);ctx.scale(cat.faceR?1:-1,1);
  ctx.imageSmoothingEnabled=false;ctx.drawImage(img,fr*sp.fw,0,sp.fw,sp.fh,-dw/2,-dh+2,dw,dh);ctx.restore();
}
