// input.js — keyboard + touch. Hard-prevents browser nav/scroll on game keys.

export const Input = {
  left:false, right:false, down:false, run:false,
  jumpBuffer:0, actionEdge:false, restartEdge:false, pauseEdge:false, lanternEdge:false,
  _down:{},
};

const JUMP=['Space','KeyW','ArrowUp'];
const LEFT=['KeyA','ArrowLeft'];
const RIGHT=['KeyD','ArrowRight'];
const DOWN=['KeyS','ArrowDown'];
// every key we fully own (preventDefault) so the page never scrolls/navigates
const OWNED=new Set([...JUMP,...LEFT,...RIGHT,...DOWN,'ShiftLeft','ShiftRight','KeyE','KeyR','KeyP','KeyM','KeyF','Space']);

function refresh(){
  Input.left =LEFT.some(k=>Input._down[k]);
  Input.right=RIGHT.some(k=>Input._down[k]);
  Input.down =DOWN.some(k=>Input._down[k]);
  Input.run  =Input._down['ShiftLeft']||Input._down['ShiftRight'];
}

window.addEventListener('keydown',e=>{
  if(OWNED.has(e.code)) e.preventDefault();
  if(!Input._down[e.code]){
    if(JUMP.includes(e.code)) Input.jumpBuffer=0.16;
    if(e.code==='KeyE') Input.actionEdge=true;
    if(e.code==='KeyF') Input.lanternEdge=true;
    if(e.code==='KeyR') Input.restartEdge=true;
    if(e.code==='KeyP'||e.code==='Escape') Input.pauseEdge=true;
  }
  Input._down[e.code]=true;
  refresh();
},{passive:false});

window.addEventListener('keyup',e=>{
  if(OWNED.has(e.code)) e.preventDefault();
  Input._down[e.code]=false; refresh();
},{passive:false});

window.addEventListener('blur',()=>{ Input._down={}; refresh(); });
// block context menu / drag that can shift layout
window.addEventListener('contextmenu',e=>e.preventDefault());

export function decayInput(dt){
  if(Input.jumpBuffer>0) Input.jumpBuffer=Math.max(0,Input.jumpBuffer-dt);
  Input.actionEdge=false; Input.restartEdge=false; Input.pauseEdge=false; Input.lanternEdge=false;
}
export function consumeJump(){
  if(Input.jumpBuffer>0){ Input.jumpBuffer=0; return true; }
  return false;
}

export function bindTouch(){
  const map=[
    ['t-left', ()=>Input._down['ArrowLeft']=true,  ()=>Input._down['ArrowLeft']=false],
    ['t-right',()=>Input._down['ArrowRight']=true, ()=>Input._down['ArrowRight']=false],
    ['t-jump', ()=>Input.jumpBuffer=0.16, ()=>{}],
    ['t-run',  ()=>Input._down['ShiftLeft']=true, ()=>Input._down['ShiftLeft']=false],
    ['t-act',  ()=>{Input.actionEdge=true;}, ()=>{}],
  ];
  map.forEach(([id,on,off])=>{
    const el=document.getElementById(id); if(!el) return;
    const s=e=>{e.preventDefault();on();refresh();};
    const f=e=>{e.preventDefault();off();refresh();};
    el.addEventListener('touchstart',s,{passive:false});
    el.addEventListener('touchend',f,{passive:false});
    el.addEventListener('mousedown',s); el.addEventListener('mouseup',f); el.addEventListener('mouseleave',f);
  });
}
