// camera.js — smooth follow camera with lookahead and bounds

export class Camera {
  constructor(viewW, viewH){
    this.x=0; this.y=0;
    this.vw=viewW; this.vh=viewH;
    this.bounds=null; // {minX,maxX,minY,maxY}
    this.shake=0;
  }
  setBounds(minX,maxX,minY,maxY){ this.bounds={minX,maxX,minY,maxY}; }
  snap(tx,ty){ this.x=tx-this.vw/2; this.y=ty-this.vh/2; this._clamp(); }

  follow(tx,ty,lookaheadX,dt){
    const targetX = tx - this.vw/2 + lookaheadX;
    const targetY = ty - this.vh/2 - 30;
    const s = 1 - Math.exp(-6*dt);      // smoothing, frame-rate independent
    this.x += (targetX - this.x)*s;
    this.y += (targetY - this.y)*s;
    if(this.shake>0) this.shake = Math.max(0, this.shake - dt*4);
    this._clamp();
  }
  _clamp(){
    if(!this.bounds) return;
    const b=this.bounds;
    this.x=Math.max(b.minX, Math.min(b.maxX - this.vw, this.x));
    this.y=Math.max(b.minY, Math.min(b.maxY - this.vh, this.y));
  }
  shakeBy(amt){ this.shake = Math.max(this.shake, amt); }
  get ox(){ return this.shake>0 ? (Math.random()-0.5)*this.shake*8 : 0; }
  get oy(){ return this.shake>0 ? (Math.random()-0.5)*this.shake*8 : 0; }
}
