// parallax.js — layered backdrops per theme. far(_2 jpg) + near(_1 png) + atmosphere.
import { IMG } from './assets.js';

const THEMES={
  meadow:{far:'meadow_far',near:'meadow_near',nearSpd:0.18,tint:'rgba(40,80,50,0.04)'},
  snow:{far:'snow_far',near:'snow_near',nearSpd:0.16,tint:'rgba(150,170,200,0.06)'},
  autumn:{far:'autumn_far',near:'autumn_near',nearSpd:0.20,tint:'rgba(120,55,25,0.06)'},
  desert:{far:'desert_far',near:'desert_near',nearSpd:0.18,tint:'rgba(170,120,50,0.05)'},
  dungeon:{far:'dungeon_far',near:'dungeon_near',nearSpd:0.16,tint:'rgba(30,55,75,0.12)'},
  redwood:{far:'redwood_far',near:'redwood_near',nearSpd:0.20,tint:'rgba(140,60,30,0.06)'},
  space:{space:true,tint:'rgba(20,10,40,0.10)'},
};

function cover(ctx,img,spd,camX,vw,vh,alpha){
  if(!img)return;
  const bw=vh*(img.width/img.height);
  let x=-(camX*spd)%bw; if(x>0)x-=bw;
  ctx.globalAlpha=alpha??1;
  for(;x<vw;x+=bw) ctx.drawImage(img,x,0,bw,vh);
  ctx.globalAlpha=1;
}

function drawSpace(ctx,cam,vw,vh){
  cover(ctx,IMG.space_bg,0.02,cam.x,vw,vh,1);
  cover(ctx,IMG.space_stars,0.06,cam.x,vw,vh,1);
  cover(ctx,IMG.space_far,0.12,cam.x,vw,vh,1);
  // big planet drifts slowly, fixed-ish
  if(IMG.space_big){const s=vh*0.5/IMG.space_big.height;const w=IMG.space_big.width*s,h=IMG.space_big.height*s;
    const x=vw*0.62-(cam.x*0.05)%(vw*2);ctx.globalAlpha=0.9;ctx.drawImage(IMG.space_big,x,vh*0.1,w,h);ctx.globalAlpha=1;}
  if(IMG.space_ring){const s=vh*0.4/IMG.space_ring.height;const w=IMG.space_ring.width*s,h=IMG.space_ring.height*s;
    const x=vw*0.2-(cam.x*0.08)%(vw*2);ctx.globalAlpha=0.85;ctx.drawImage(IMG.space_ring,x,vh*0.15,w,h);ctx.globalAlpha=1;}
}

export function drawParallax(ctx,theme,cam,vw,vh){
  const T=THEMES[theme]||THEMES.meadow;
  if(T.space){ drawSpace(ctx,cam,vw,vh); }
  else {
    cover(ctx,IMG[T.far],0.05,cam.x,vw,vh,1);     // far (opaque)
    cover(ctx,IMG[T.near],T.nearSpd,cam.x,vw,vh,1);// near detail (transparent)
  }
  if(T.tint){ctx.fillStyle=T.tint;ctx.fillRect(0,0,vw,vh);}
}
