// lighting.js — renders the "hollow" darkness overlay with a lantern light around
// the player, plus glow pools at orbs/torches. Drawn in SCREEN space after the world.

let lanternOn = true;
let darkEnabled = true;
let flicker = 0;

export function setLantern(on){ lanternOn = on; }
export function toggleLantern(){ lanternOn = !lanternOn; return lanternOn; }
export function isLanternOn(){ return lanternOn; }
export function setDark(on){ darkEnabled = on; }
export function isDark(){ return darkEnabled; }

// theme -> base darkness alpha (how hollow it feels)
const DARKNESS = {
  meadow:0.42, snow:0.40, autumn:0.55, desert:0.46, dungeon:0.80, redwood:0.6, space:0.7,
};

// px,py = player center in SCREEN space. lights = [{x,y,r}] extra glows (screen space).
export function drawLighting(ctx, theme, vw, vh, px, py, dt, extraLights){
  if(!darkEnabled) return;
  flicker += dt*12;
  const baseDark = DARKNESS[theme] ?? 0.5;

  // Build a darkness layer with "holes" punched by lights using an offscreen buffer
  const buf = drawLighting._buf || (drawLighting._buf = document.createElement('canvas'));
  if(buf.width!==vw||buf.height!==vh){ buf.width=vw; buf.height=vh; }
  const b = buf.getContext('2d');
  b.clearRect(0,0,vw,vh);

  // fill darkness
  b.fillStyle = `rgba(2,3,8,${baseDark})`;
  b.fillRect(0,0,vw,vh);

  // punch lights with destination-out + radial gradients
  b.globalCompositeOperation = 'destination-out';

  // lantern around player
  if(lanternOn){
    const fl = 1 + Math.sin(flicker)*0.04 + Math.sin(flicker*2.3)*0.02;
    const r = 210*fl;
    const g = b.createRadialGradient(px,py,12, px,py,r);
    g.addColorStop(0,'rgba(0,0,0,1)');
    g.addColorStop(0.55,'rgba(0,0,0,0.85)');
    g.addColorStop(1,'rgba(0,0,0,0)');
    b.fillStyle=g;
    b.beginPath(); b.arc(px,py,r,0,Math.PI*2); b.fill();
  } else {
    // tiny safety light even when off, so you're not fully blind
    const r=70;
    const g=b.createRadialGradient(px,py,6,px,py,r);
    g.addColorStop(0,'rgba(0,0,0,0.7)'); g.addColorStop(1,'rgba(0,0,0,0)');
    b.fillStyle=g; b.beginPath(); b.arc(px,py,r,0,Math.PI*2); b.fill();
  }

  // extra lights (orbs, torches, exit) — soft pools
  if(extraLights){
    for(const L of extraLights){
      const g=b.createRadialGradient(L.x,L.y,2,L.x,L.y,L.r);
      g.addColorStop(0,`rgba(0,0,0,${L.a??0.8})`);
      g.addColorStop(1,'rgba(0,0,0,0)');
      b.fillStyle=g; b.beginPath(); b.arc(L.x,L.y,L.r,0,Math.PI*2); b.fill();
    }
  }

  b.globalCompositeOperation = 'source-over';

  // composite darkness over the scene
  ctx.drawImage(buf,0,0);

  // warm lantern tint inside the light
  if(lanternOn){
    const fl=1+Math.sin(flicker)*0.04;
    const r=200*fl;
    const wg=ctx.createRadialGradient(px,py,10,px,py,r);
    wg.addColorStop(0,'rgba(255,210,140,0.12)');
    wg.addColorStop(0.6,'rgba(255,190,110,0.05)');
    wg.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=wg; ctx.beginPath(); ctx.arc(px,py,r,0,Math.PI*2); ctx.fill();
  }
}
