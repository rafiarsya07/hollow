// segments.js — library of reusable challenge "chunks".
// Each chunk is a function(ox) that returns geometry offset by ox (world X).
// All chunks are GROUND_Y aligned; they return {width, platforms, oneWay, crumble,
// fakePlat, spikes, fallSpikes, spikeTimer, cannons, springs, conveyors,
// toggleBlocks, disappearing, windZones, invisible, bats, movers, levers, gates, orbs, checkpoints}.
// The composer stitches many chunks into one long level.

const GY = 480;          // nominal ground top
const FLOOR_H = 320;

// helper to make a base floor block
const floor=(x,w,y=GY)=>({x,y,w,h:FLOOR_H});

let gateSeq=0;
function gid(){ return 'g'+(gateSeq++); }

// Each builder: (ox) => partial level fields. width = how far to advance.
export const CHUNKS = {

  // 0 — safe breather with orbs
  rest(ox){
    return { width:360, platforms:[floor(ox,360)],
      orbs:[{x:ox+120,y:GY-60},{x:ox+240,y:GY-60}] };
  },

  // 1 — gap with a single jump
  gap(ox){
    return { width:420, platforms:[floor(ox,160), floor(ox+260,160)],
      orbs:[{x:ox+210,y:GY-80}] };
  },

  // 2 — crumble bridge over spikes (RAGE: must keep moving)
  crumbleBridge(ox){
    const cr=[]; for(let i=0;i<5;i++) cr.push({x:ox+120+i*60,y:GY-2,w:50});
    return { width:560, platforms:[floor(ox,120),floor(ox+440,120)],
      crumble:cr, spikes:[{x:ox+120,y:GY+40,w:320}],
      orbs:[{x:ox+280,y:GY-90}] };
  },

  // 3 — fake floor troll (one of the "floors" vanishes)
  fakeFloorTroll(ox){
    return { width:520, platforms:[floor(ox,140),floor(ox+380,140)],
      fakePlat:[{x:ox+200,y:GY,w:120,h:20}],         // looks like safe ground -> drops you
      spikes:[{x:ox+140,y:GY+120,w:240}],
      oneWay:[{x:ox+200,y:GY-110,w:120}],            // the REAL path is above
      orbs:[{x:ox+260,y:GY-150}] };
  },

  // 4 — retracting spike corridor (timing)
  spikeTunnel(ox){
    const st=[]; for(let i=0;i<4;i++) st.push({x:ox+140+i*120,y:GY-2,w:90,period:1.3,phase:i*0.32});
    return { width:680, platforms:[floor(ox,680)], spikeTimer:st,
      orbs:[{x:ox+200,y:GY-70},{x:ox+440,y:GY-70}] };
  },

  // 5 — falling spike blocks (drop when you pass under)
  fallingSpikes(ox){
    const fs=[]; for(let i=0;i<3;i++) fs.push({x:ox+180+i*140,y:GY-180,w:46,triggerX:ox+180+i*140});
    return { width:560, platforms:[floor(ox,560)], fallSpikes:fs,
      orbs:[{x:ox+250,y:GY-60},{x:ox+390,y:GY-60}] };
  },

  // 6 — cannon hallway (projectiles fly across)
  cannonRun(ox){
    return { width:600, platforms:[floor(ox,600)],
      cannons:[{x:ox+560,y:GY-40,dir:-1,period:1.6,phase:0,spd:280},
               {x:ox+560,y:GY-110,dir:-1,period:1.6,phase:0.8,spd:300}],
      oneWay:[{x:ox+200,y:GY-90,w:90},{x:ox+360,y:GY-150,w:90}],
      orbs:[{x:ox+245,y:GY-130},{x:ox+405,y:GY-190}] };
  },

  // 7 — disappearing rhythm blocks across a pit
  rhythmBlocks(ox){
    const d=[]; for(let i=0;i<5;i++) d.push({x:ox+150+i*90,y:GY-40,w:60,period:1.8,phase:i*0.36});
    return { width:680, platforms:[floor(ox,120),floor(ox+560,120)],
      disappearing:d, spikes:[{x:ox+120,y:GY+60,w:440}],
      orbs:[{x:ox+330,y:GY-100}] };
  },

  // 8 — toggle-block puzzle (lever flips which blocks are solid)
  toggleGate(ox){
    const g=gid();
    return { width:640, platforms:[floor(ox,180),floor(ox+460,180)],
      levers:[{x:ox+90,y:GY-50,gate:g}],
      gates:[{id:g,x:ox+300,y:GY-220,w:24,h:220}],
      toggleBlocks:[{x:ox+220,y:GY-50,w:80,h:18,onWhenGate:g}],
      spikes:[{x:ox+180,y:GY+40,w:280}],
      oneWay:[{x:ox+360,y:GY-130,w:90}],
      orbs:[{x:ox+250,y:GY-90},{x:ox+405,y:GY-170}] };
  },

  // 9 — spring launch over tall wall
  springWall(ox){
    return { width:560, platforms:[floor(ox,200),floor(ox+360,200),
              {x:ox+250,y:GY-260,w:60,h:260}],     // tall wall
      springs:[{x:ox+150,y:GY-12,w:46,power:980}],
      orbs:[{x:ox+250,y:GY-320},{x:ox+430,y:GY-60}] };
  },

  // 10 — conveyor belts (fight the drift) over spikes
  conveyorPit(ox){
    return { width:620, platforms:[floor(ox,120),floor(ox+500,120)],
      conveyors:[{x:ox+150,y:GY-30,w:140,h:18,dir:-1,spd:120},
                 {x:ox+330,y:GY-30,w:140,h:18,dir:1,spd:140}],
      spikes:[{x:ox+120,y:GY+50,w:380}],
      orbs:[{x:ox+300,y:GY-90}] };
  },

  // 11 — diving bat ambush
  batPit(ox){
    return { width:600, platforms:[floor(ox,600)],
      bats:[{x:ox+200,y:GY-150,x1:ox+150,x2:ox+450,spd:160,dive:true},
            {x:ox+400,y:GY-180,x1:ox+250,x2:ox+550,spd:180,dive:true}],
      orbs:[{x:ox+300,y:GY-70}] };
  },

  // 12 — invisible block troll (revealed when bumped from below)
  invisibleTroll(ox){
    return { width:540, platforms:[floor(ox,160),floor(ox+380,160)],
      invisible:[{x:ox+250,y:GY-130,w:60,h:18}],   // need this to cross but it's hidden
      spikes:[{x:ox+160,y:GY+60,w:220}],
      orbs:[{x:ox+280,y:GY-200}] };
  },

  // 13 — wind zone (pushes you toward spikes)
  windGap(ox){
    return { width:580, platforms:[floor(ox,180),floor(ox+400,180)],
      windZones:[{x:ox+180,y:GY-220,w:220,h:220,fx:-220}],
      spikes:[{x:ox,y:GY-2,w:60}],
      orbs:[{x:ox+290,y:GY-110}] };
  },

  // 14 — vertical mover climb with bats
  moverClimb(ox){
    return { width:600, platforms:[floor(ox,160),floor(ox+440,160)],
      movers:[{x:ox+220,y:GY-60,w:90,h:18,axis:'y',lo:GY-260,hi:GY-60,spd:70}],
      bats:[{x:ox+350,y:GY-220,x1:ox+260,x2:ox+440,spd:150,dive:true}],
      orbs:[{x:ox+265,y:GY-300}] };
  },


  // 16 — ground patrol (goblins/wolves walking back and forth)
  patrol(ox){
    return { width:560, platforms:[floor(ox,560)],
      enemies:[{type:'walker',sprite:'en_goblin',x:ox+200,y:GY,x1:ox+120,x2:ox+440,spd:70},
               {type:'walker',sprite:'en_wolf',x:ox+380,y:GY,x1:ox+240,x2:ox+520,spd:110}],
      orbs:[{x:ox+280,y:GY-70}] };
  },

  // 17 — ghost floaters (drift through platforms, sine bob)
  hauntGap(ox){
    return { width:600, platforms:[floor(ox,180),floor(ox+420,180)],
      enemies:[{type:'ghost',sprite:'en_ghost',x:ox+300,y:GY-120,x1:ox+200,x2:ox+420,spd:90,bob:40},
               {type:'ghost',sprite:'en_ghost',x:ox+360,y:GY-200,x1:ox+220,x2:ox+440,spd:70,bob:60}],
      spikes:[{x:ox+180,y:GY+40,w:240}],
      orbs:[{x:ox+300,y:GY-90}] };
  },

  // 18 — scorpion/lizard pit dwellers + crumble
  denPit(ox){
    const cr=[]; for(let i=0;i<3;i++)cr.push({x:ox+260+i*60,y:GY-2,w:50});
    return { width:620, platforms:[floor(ox,200),floor(ox+440,180)],
      crumble:cr,
      enemies:[{type:'walker',sprite:'en_scorpion',x:ox+120,y:GY,x1:ox+40,x2:ox+200,spd:90},
               {type:'walker',sprite:'en_lizard',x:ox+500,y:GY,x1:ox+440,x2:ox+600,spd:120}],
      spikes:[{x:ox+200,y:GY+40,w:240}],
      orbs:[{x:ox+330,y:GY-80}] };
  },


  // 19 — FALLING TREE trap: a tree topples across the path when you get close
  treefallTrap(ox){
    return { width:640, platforms:[floor(ox,640)],
      treefalls:[{x:ox+360,y:GY,triggerX:ox+200,w:60}],
      props:[{sprite:'prop_bush',x:ox+120,y:GY},{sprite:'prop_rock',x:ox+560,y:GY},
             {sprite:'prop_fern',x:ox+170,y:GY}],
      orbs:[{x:ox+300,y:GY-70},{x:ox+470,y:GY-120},{x:ox+600,y:GY-70}],
      checkpoints:[{x:ox+40,y:GY}] };
  },

  // 20 — haunted clearing: ghosts + dark, with decorative dead props
  hauntedClearing(ox){
    return { width:640, platforms:[floor(ox,640)],
      enemies:[{type:'ghost',sprite:'en_ghost',x:ox+250,y:GY-130,x1:ox+150,x2:ox+450,spd:80,bob:50},
               {type:'ghost',sprite:'en_ghost',x:ox+450,y:GY-170,x1:ox+300,x2:ox+560,spd:60,bob:70}],
      props:[{sprite:'prop_shrub',x:ox+100,y:GY},{sprite:'prop_mushroom',x:ox+520,y:GY},
             {sprite:'prop_fern',x:ox+340,y:GY}],
      orbs:[{x:ox+320,y:GY-90}],
      ghostMoan:true };
  },

  // 15 — the gauntlet finale (everything at once)
  gauntlet(ox){
    const g=gid(); const cr=[]; for(let i=0;i<3;i++)cr.push({x:ox+360+i*60,y:GY-2,w:50});
    return { width:900, platforms:[floor(ox,160),floor(ox+560,120),floor(ox+780,120)],
      spikeTimer:[{x:ox+180,y:GY-2,w:90,period:1.1,phase:0},
                  {x:ox+270,y:GY-2,w:90,period:1.1,phase:0.5}],
      crumble:cr, spikes:[{x:ox+360,y:GY+50,w:200}],
      cannons:[{x:ox+560,y:GY-50,dir:-1,period:1.3,phase:0,spd:320}],
      bats:[{x:ox+650,y:GY-160,x1:ox+560,x2:ox+760,spd:190,dive:true}],
      movers:[{x:ox+520,y:GY-40,w:90,h:18,axis:'x',lo:ox+460,hi:ox+560,spd:120}],
      orbs:[{x:ox+225,y:GY-70},{x:ox+430,y:GY-100},{x:ox+700,y:GY-220}],
      checkpoints:[{x:ox+40,y:GY}] };
  },
};

// Per-theme chunk recipes — ordered difficulty curve, ~10 min of play.
// Each entry is a chunk name; composer adds checkpoints periodically.
const RECIPES = {
  meadow:['rest','gap','patrol','crumbleBridge','treefallTrap','rest','fakeFloorTroll','batPit','gap',
          'spikeTunnel','patrol','rest','rhythmBlocks','hauntGap','fallingSpikes','crumbleBridge',
          'springWall','treefallTrap','rest','invisibleTroll','denPit','batPit','gauntlet','rest'],
  snow:['rest','gap','spikeTunnel','patrol','moverClimb','crumbleBridge','batPit','hauntGap','treefallTrap',
        'fakeFloorTroll','rhythmBlocks','windGap','toggleGate','rest','fallingSpikes','conveyorPit',
        'denPit','springWall','batPit','invisibleTroll','patrol','gauntlet','rest'],
  autumn:['rest','crumbleBridge','patrol','batPit','treefallTrap','fakeFloorTroll','cannonRun','spikeTunnel','hauntedClearing',
          'rhythmBlocks','windGap','toggleGate','fallingSpikes','denPit','rest','conveyorPit',
          'moverClimb','invisibleTroll','hauntedClearing','batPit','springWall','patrol','gauntlet','rest'],
  desert:['rest','fakeFloorTroll','patrol','crumbleBridge','cannonRun','conveyorPit','spikeTunnel','denPit',
          'fallingSpikes','windGap','batPit','toggleGate','rhythmBlocks','hauntGap','treefallTrap','rest',
          'invisibleTroll','moverClimb','cannonRun','springWall','patrol','gauntlet','rest'],
  dungeon:['rest','spikeTunnel','cannonRun','patrol','fallingSpikes','crumbleBridge','batPit','hauntedClearing',
           'toggleGate','rhythmBlocks','windGap','conveyorPit','denPit','invisibleTroll','hauntedClearing',
           'moverClimb','fakeFloorTroll','cannonRun','batPit','springWall','spikeTunnel','gauntlet'],
};

// Compose a full long level for a theme.
export function composeLevel(theme){
  gateSeq=0;
  const recipe=RECIPES[theme]||RECIPES.meadow;
  const out={ platforms:[],oneWay:[],crumble:[],fakePlat:[],spikes:[],fallSpikes:[],
    spikeTimer:[],cannons:[],springs:[],conveyors:[],toggleBlocks:[],disappearing:[],
    windZones:[],invisible:[],bats:[],movers:[],levers:[],gates:[],orbs:[],checkpoints:[],enemies:[],props:[],treefalls:[] };
  let ox=0; let chunkCount=0;
  // start pad
  out.platforms.push(floor(-200,400));
  ox=200;
  for(const name of recipe){
    const c=CHUNKS[name](ox);
    for(const key of Object.keys(out)){
      if(c[key]) out[key].push(...c[key]);
    }
    // auto checkpoint every 3 chunks at the chunk start (on ground)
    if(chunkCount%3===0 && name!=='rest'){
      out.checkpoints.push({x:ox+30,y:GY});
    }
    ox+=c.width;
    chunkCount++;
  }
  // end pad + exit
  out.platforms.push(floor(ox,400));
  out.exit={x:ox+220,y:GY-70,w:48,h:70};
  out.spawn={x:60,y:GY-80};
  out.width=ox+400;
  out.groundY=GY;
  return out;
}

// Boss arena: flat floor, the three-form sorcerer, projectiles handled in main.
export function composeBoss(){
  gateSeq=0;
  const GYb=GY;
  return {
    platforms:[ {x:-200,y:GYb,w:1600,h:FLOOR_H},
                {x:120,y:GYb-160,w:120,h:18}, {x:1080,y:GYb-160,w:120,h:18},
                {x:600,y:GYb-240,w:140,h:18} ],
    oneWay:[],crumble:[],fakePlat:[],spikes:[],fallSpikes:[],spikeTimer:[],
    cannons:[],projectiles:[],springs:[],conveyors:[],toggleBlocks:[],disappearing:[],
    windZones:[],invisible:[],bats:[],movers:[],levers:[],gates:[],
    orbs:[],checkpoints:[{x:80,y:GYb}],
    enemies:[],
    boss:{x:1300,y:GYb-110,form:1,hp:9,maxhp:9,phase:0,t:0,castT:0,dead:false},
    spawn:{x:120,y:GYb-80},
    exit:null, // exit appears after boss dies
    groundY:GYb, width:1500, isBoss:true,
  };
}
