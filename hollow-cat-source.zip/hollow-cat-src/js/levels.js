// levels.js — 5 long worlds + boss finale, with connecting story.
import { composeLevel, composeBoss } from './segments.js';

const META=[
  {num:'World I',title:'The Meadow',theme:'meadow',music:'m_forest',
   desc:'A man wakes in a world drained of light.\nIn the grass, a small black cat is watching him.',
   recipe:'meadow', meetFrac:0.5},
  {num:'World II',title:'The Snow Pass',theme:'snow',music:'m_cave',
   desc:'The cat leads him north, into the cold.\nThe shadow took the light from here first.',
   recipe:'snow'},
  {num:'World III',title:'The Autumn Wood',theme:'autumn',music:'m_swamp',
   desc:'Red leaves, and red eyes between the trunks.\nThey are getting closer to the source.',
   recipe:'autumn'},
  {num:'World IV',title:'The Oasis',theme:'desert',music:'m_cave',
   desc:'Warm sand hides cold traps.\nThe sorcerer\'s servants guard the way.',
   recipe:'desert'},
  {num:'World V',title:'The Deep',theme:'dungeon',music:'m_dungeon',
   desc:'Down, into wet stone and torchlight.\nThe stolen light glows somewhere below.',
   recipe:'dungeon'},
  {num:'Finale',title:'The Void',theme:'space',music:'m_boss',
   desc:'Beyond the world, the shadow waits in three forms.\nReturn the light. Together.',
   isBoss:true},
];

export const LEVELS = META.map(m=>{
  if(m.isBoss){ return {...m, ...composeBoss()}; }
  const c=composeLevel(m.recipe);
  const lv={...m, ...c};
  if(m.meetFrac) lv.meet={x:c.width*m.meetFrac, y:c.groundY-40};
  return lv;
});
