// audio.js — simple SFX + music manager with volume + looping

import { SND } from './assets.js';
let musicEnabled=true, sfxEnabled=true;

let musicEl=null, musicKey=null;
let muted=false;

export function playSfx(key, vol=0.6){
  if(muted||!sfxEnabled) return;
  const base=SND[key];
  if(!base) return;
  try{
    const a=base.cloneNode();
    a.volume=vol;
    a.play().catch(()=>{});
  }catch(e){}
}

export function playMusic(key, vol=0.35){
  if(!musicEnabled){stopMusic();musicKey=key;return;}
  if(musicKey===key) return;
  stopMusic();
  const el=SND[key];
  if(!el) return;
  musicEl=el; musicKey=key;
  el.loop=true; el.volume=muted?0:vol;
  el.currentTime=0;
  el.play().catch(()=>{});
}

export function stopMusic(){
  if(musicEl){ try{musicEl.pause();}catch(e){} }
  musicEl=null; musicKey=null;
}

export function toggleMute(){
  muted=!muted;
  if(musicEl) musicEl.volume=muted?0:0.35;
  return muted;
}
export function isMuted(){ return muted; }

export function setMusicEnabled(on){ musicEnabled=on; if(musicEl)musicEl.volume=on?0.35:0; }
export function setSfxEnabled(on){ sfxEnabled=on; }
