import { loadAssets } from './assets.js';
import { Input, decayInput, bindTouch } from './input.js';
import { Camera } from './camera.js';
import { LEVELS } from './levels.js';
import { drawParallax } from './parallax.js';
import { drawWorld, drawPartner } from './world.js';
import { Player } from './player.js';
import { playSfx, playMusic, stopMusic, toggleMute, setMusicEnabled, setSfxEnabled } from './audio.js';
import { drawLighting, toggleLantern, isLanternOn, setLantern, setDark, isDark } from './lighting.js';

let VW=960,VH=540;            // virtual view; adapts to window aspect
const BASE_H=540;
const canvas=document.getElementById('game'), ctx=canvas.getContext('2d');
let sc=1,ox=0,oy=0;
function resize(){
  const dpr=Math.min(devicePixelRatio||1,2);
  canvas.width=Math.floor(innerWidth*dpr);canvas.height=Math.floor(innerHeight*dpr);
  canvas.style.width=innerWidth+'px';canvas.style.height=innerHeight+'px';
  // keep a fixed virtual HEIGHT, derive WIDTH from the real aspect ratio so the
  // canvas always fills the screen (no big letterbox bars on odd window shapes)
  const aspect=innerWidth/innerHeight;
  VH=BASE_H; VW=Math.round(BASE_H*aspect);
  // clamp so the view never gets absurd
  VW=Math.max(640,Math.min(1280,VW));
  if(G&&G.cam){ G.cam.vw=VW; G.cam.vh=VH; }
  sc=canvas.height/VH;
  ox=(canvas.width-VW*sc)/2;oy=0;
}
addEventListener('resize',()=>resize());

const $=id=>document.getElementById(id);
const show=id=>$(id).classList.remove('hidden');
const hide=id=>$(id).classList.add('hidden');
const fade=id=>$(id).classList.add('hidden');

const G={mode:'loading',levelIndex:0,level:null,st:null,orbsGot:0,
  player:new Player('broo'),cam:new Camera(VW,VH),
  chapterTimer:0,deathTimer:0,respawnPoint:null,hasCat:false,
  partner:{active:false,x:0,y:0,w:30,h:34,vx:0,faceR:true,trail:[]},
  storyTimer:0,paused:false,deaths:0,time:0};
resize();  // now G exists; set up viewport

function buildState(lv){
  return {
    oneWay:(lv.oneWay||[]).map(o=>({...o})),
    crumble:(lv.crumble||[]).map(c=>({...c,triggered:false,t:0,gone:false})),
    fakePlat:(lv.fakePlat||[]).map(f=>({...f,_fell:false,_wobble:false,_t:0})),
    fallSpikes:(lv.fallSpikes||[]).map(f=>({...f,_y:f.y,_falling:false,_armed:true})),
    spikeTimer:(lv.spikeTimer||[]).map(s=>({...s,_out:1})),
    cannons:(lv.cannons||[]).map(c=>({...c})),
    projectiles:[],
    springs:(lv.springs||[]).map(s=>({...s,_fire:0})),
    conveyors:(lv.conveyors||[]).map(c=>({...c})),
    toggleBlocks:(lv.toggleBlocks||[]).map(t=>({...t,_solid:false})),
    disappearing:(lv.disappearing||[]).map(d=>({...d,_vis:1})),
    windZones:(lv.windZones||[]).map(w=>({...w})),
    invisible:(lv.invisible||[]).map(i=>({...i,_shown:false})),
    bats:(lv.bats||[]).map(b=>({...b,dir:1,vx:b.spd,diveT:0,diving:false,baseY:b.y})),
    movers:(lv.movers||[]).map(m=>({...m,dir:1,_dx:0,_dy:0})),
    levers:(lv.levers||[]).map(l=>({...l,active:false})),
    gates:(lv.gates||[]).map(g=>({...g,open:false})),
    orbs:(lv.orbs||[]).map(o=>({...o,taken:false})),
    checkpoints:(lv.checkpoints||[]).map(c=>({...c,reached:false})),
    enemies:(lv.enemies||[]).map(e=>({...e,vx:e.spd||0,dir:1,dead:false,baseY:e.y})),
    props:(lv.props||[]).map(p=>({...p})),
    treefalls:(lv.treefalls||[]).map(t=>({...t,_falling:false,_fallen:false,_ang:0,_armed:true})),
    ghostMoanZones:(lv.enemies||[]).filter(e=>e.type==='ghost').length?true:false,
    boss: lv.boss?{...lv.boss}:null,
    bossShots:[],
    meet:lv.meet?{...lv.meet,done:false}:null,
  };
}

function loadLevel(i){
  const lv=LEVELS[i];
  G.levelIndex=i;G.level=lv;G.orbsGot=0;G.time=0;
  G.st=buildState(lv);
  G.player.setSkin('broo');
  G.player.reset(lv.spawn.x,lv.spawn.y);
  G.respawnPoint={x:lv.spawn.x,y:lv.spawn.y};
  G.partner.active=G.hasCat;
  G.partner.x=lv.spawn.x-40;G.partner.y=lv.spawn.y;G.partner.trail=[];
  G.cam.setBounds(-200,lv.width,-400,900);
  G.cam.snap(lv.spawn.x,lv.spawn.y);
  $('hud-world').textContent=lv.num+' · '+lv.title;
  $('hud-orbs').textContent='0';$('hud-orbs-total').textContent=(lv.orbs||[]).length;
  $('ch-num').textContent=lv.num;$('ch-title').textContent=lv.title;$('ch-desc').textContent=lv.desc;
  show('chapter-card');$('chapter-card').classList.remove('hidden');
  G.chapterTimer=3.0;G.mode='chapter';hide('hud');
  if(lv.music)playMusic(lv.music);
  setLantern(true);
  G._moanT=4+Math.random()*5;
}

function solids(){
  const s=[],pl=G.player,st=G.st;
  for(const p of G.level.platforms) s.push({x:p.x,y:p.y,w:p.w,h:p.h});
  for(const m of st.movers) s.push({x:m.x,y:m.y,w:m.w,h:m.h,ref:m});
  for(const c of st.conveyors) s.push({x:c.x,y:c.y,w:c.w,h:c.h,conveyor:c});
  for(const g of st.gates) if(!g.open) s.push({x:g.x,y:g.y,w:g.w,h:g.h});
  for(const c of st.crumble) if(!c.gone) s.push({x:c.x,y:c.y,w:c.w,h:16,ref:c,crumble:true});
  for(const f of st.fakePlat) if(!f._fell) s.push({x:f.x,y:f.y,w:f.w,h:f.h||20,ref:f,fake:true});
  for(const t of st.toggleBlocks) if(t._solid) s.push({x:t.x,y:t.y,w:t.w,h:t.h});
  for(const d of st.disappearing) if(d._vis>0.5) s.push({x:d.x,y:d.y,w:d.w,h:16});
  for(const iv of st.invisible) if(iv._shown) s.push({x:iv.x,y:iv.y,w:iv.w,h:iv.h});
  // fallen tree trunk = a low log obstacle you must jump over
  for(const t of st.treefalls) if(t._fallen) s.push({x:t.x-6,y:G.level.groundY-40,w:200,h:40});
  if(pl.vy>=0){ for(const o of st.oneWay) if(pl.y+pl.h<=o.y+8) s.push({x:o.x,y:o.y,w:o.w,h:8}); }
  return s;
}

function updatePlay(dt,ts){
  const st=G.st,pl=G.player;
  G.time+=dt;

  // movers
  for(const m of st.movers){const px=m.x,py=m.y;
    if(m.axis==='x'){m.x+=m.spd*m.dir*dt;if(m.x>=m.hi){m.x=m.hi;m.dir=-1;}else if(m.x<=m.lo){m.x=m.lo;m.dir=1;}}
    else{m.y+=m.spd*m.dir*dt;if(m.y>=m.hi){m.y=m.hi;m.dir=-1;}else if(m.y<=m.lo){m.y=m.lo;m.dir=1;}}
    m._dx=m.x-px;m._dy=m.y-py;}

  // timed spikes
  for(const s of st.spikeTimer){
    const ph=((ts/1000)+s.phase)%s.period;
    s._out= ph<s.period*0.5?1:Math.max(0,1-(ph-s.period*0.5)/(s.period*0.18));
    if(ph>=s.period*0.68)s._out=ph<s.period*0.86?0:(ph-s.period*0.86)/(s.period*0.14);
  }
  // disappearing blocks
  for(const d of st.disappearing){
    const ph=((ts/1000)+d.phase)%d.period;
    d._vis= ph<d.period*0.6?1:Math.max(0,1-(ph-d.period*0.6)/(d.period*0.2));
    if(ph>d.period*0.8)d._vis=ph<d.period*0.95?0:(ph-d.period*0.95)/(d.period*0.05);
  }
  // toggle blocks track lever
  for(const t of st.toggleBlocks){
    const g=st.gates.find(g=>g.id===t.onWhenGate);
    t._solid = g?g.open:false;
  }
  // cannons fire
  for(const c of st.cannons){
    const ph=((ts/1000)+c.phase)%c.period;
    if(!c._last)c._last=ph;
    if(ph<c._last){ st.projectiles.push({x:c.x,y:c.y,vx:c.spd*c.dir,life:4}); }
    c._last=ph;
  }
  for(const p of st.projectiles){ p.x+=p.vx*dt; p.life-=dt; }
  st.projectiles=st.projectiles.filter(p=>p.life>0);

  // bats
  for(const b of st.bats){
    if(b.dive){const dx=pl.x-b.x;
      if(!b.diving&&Math.abs(dx)<60&&pl.y>b.y){b.diving=true;b.diveT=0;}
      if(b.diving){b.diveT+=dt;b.y=b.baseY+Math.sin(b.diveT*4)*70;if(b.diveT>1.4){b.diving=false;b.y=b.baseY;}}}
    b.x+=b.vx*dt;
    if(b.x>=b.x2){b.x=b.x2;b.vx=-Math.abs(b.spd);}else if(b.x<=b.x1){b.x=b.x1;b.vx=Math.abs(b.spd);}
  }

  // falling spikes — drop when player passes under
  for(const f of st.fallSpikes){
    if(f._armed&&!f._falling&&Math.abs((pl.x+pl.w/2)-(f.x+f.w/2))<40&&pl.y>f._y){f._falling=true;f._armed=false;}
    if(f._falling){f._vy=(f._vy||0)+1800*dt;f._y+=f._vy*dt;
      if(f._y>820)f._falling=false;}
  }

  // wind affects player before move sweep (apply as velocity nudge)
  for(const w of st.windZones){
    if(pl.x+pl.w>w.x&&pl.x<w.x+w.w&&pl.y+pl.h>w.y&&pl.y<w.y+w.h){ pl.vx+=w.fx*dt; }
  }

  // player physics
  pl.update(dt,solids());

  // conveyor drift if standing on one
  if(pl.onMover&&pl.onMover.conveyor){ pl.x+=pl.onMover.conveyor.dir*pl.onMover.conveyor.spd*dt; }
  if(pl.onMover&&pl.onMover.axis==='y'&&pl.grounded) pl.y+=pl.onMover._dy;

  // springs
  for(const s of st.springs){
    if(pl.x+pl.w>s.x&&pl.x<s.x+s.w&&pl.y+pl.h>=s.y-6&&pl.y+pl.h<=s.y+12&&pl.vy>=0){
      pl.vy=-s.power;pl.grounded=false;s._fire=0.2;playSfx('jump',0.6);
    }
    if(s._fire>0)s._fire-=dt;
  }

  // fake platform: wobble then fall when stood on
  if(pl.onMover&&pl.onMover.fake){const f=pl.onMover;
    if(!f._wobble){f._wobble=true;f._t=0;}
  }
  for(const f of st.fakePlat){ if(f._wobble&&!f._fell){f._t+=dt;if(f._t>0.35){f._fell=true;}} }

  // crumble trigger
  if(pl.onMover&&pl.onMover.crumble&&!pl.onMover.triggered) pl.onMover.triggered=true;
  for(const c of st.crumble){ if(c.triggered&&!c.gone){c.t+=dt;if(c.t>0.45)c.gone=true;} }

  // invisible blocks reveal when hit from below (head bump)
  for(const iv of st.invisible){
    if(!iv._shown){
      if(pl.vy<0&&pl.x+pl.w>iv.x&&pl.x<iv.x+iv.w&&Math.abs(pl.y-(iv.y+iv.h))<14){
        iv._shown=true;pl.vy=0;playSfx('collect',0.4);
      }
    }
  }

  // carry vertical movers
  for(const m of st.movers){ if(m.axis==='y'&&Math.abs((pl.y+pl.h)-m.y)<6&&pl.x+pl.w>m.x&&pl.x<m.x+m.w) pl.y+=m._dy; }

  // levers
  if(Input.actionEdge){
    for(const lv of st.levers){
      if(Math.abs(pl.x+pl.w/2-lv.x)<55&&Math.abs(pl.y+pl.h-lv.y)<70){
        lv.active=!lv.active;const g=st.gates.find(g=>g.id===lv.gate);if(g)g.open=lv.active;playSfx('lever',0.6);
      }
    }
  }
  if(Input.restartEdge) respawn();
  if(Input.pauseEdge) togglePause();
  if(Input.lanternEdge){ const on=toggleLantern(); updateLanternBtn(on); playSfx('lever',0.3); }

  // checkpoints
  for(const cp of st.checkpoints){
    if(!cp.reached&&Math.abs(pl.x+pl.w/2-cp.x)<30){cp.reached=true;G.respawnPoint={x:cp.x,y:cp.y-pl.h};playSfx('collect',0.4);}
  }
  // orbs
  for(const o of st.orbs){if(o.taken)continue;const dx=pl.x+pl.w/2-o.x,dy=pl.y+pl.h/2-o.y;
    if(dx*dx+dy*dy<34*34){o.taken=true;G.orbsGot++;$('hud-orbs').textContent=G.orbsGot;playSfx('collect',0.5);}}


  // ground/ghost enemies
  for(const e of st.enemies){
    if(e.dead)continue;
    if(e.type==='ghost'){
      e.x+=e.vx*dt;
      if(e.x>=e.x2){e.x=e.x2;e.vx=-Math.abs(e.spd);}else if(e.x<=e.x1){e.x=e.x1;e.vx=Math.abs(e.spd);}
      e.y=e.baseY+Math.sin(ts*0.003+e.x*0.02)*(e.bob||30);
    } else { // walker
      e.x+=e.vx*dt;
      if(e.x>=e.x2){e.x=e.x2;e.vx=-Math.abs(e.spd);}else if(e.x<=e.x1){e.x=e.x1;e.vx=Math.abs(e.spd);}
    }
    // stomp: player falling onto enemy head kills it; side hit kills player
    const ew=30,eh=e.type==='ghost'?34:40;
    if(pl.x+6<e.x+ew/2&&pl.x+pl.w-6>e.x-ew/2&&pl.y+pl.h>e.y-eh&&pl.y+pl.h<e.y+6){
      if(pl.vy>120){ e.dead=true; pl.vy=-360; playSfx('hit',0.5); G.orbsGot+=0; }
    } else if(pl.x+8<e.x+ew/2&&pl.x+pl.w-8>e.x-ew/2&&pl.y+8<e.y&&pl.y+pl.h-6>e.y-eh){
      die(); return;
    }
  }

  // boss
  if(st.boss&&!st.boss.dead){
    const b=st.boss; b.t+=dt; b.castT=Math.max(0,b.castT-dt);
    // drift toward player slowly, stay airborne
    const tx=pl.x+ (pl.x<b.x?200:-200);
    b.x+=Math.sign(tx-b.x)*40*dt;
    b.x=Math.max(200,Math.min(1300,b.x));
    // cast on timer; rate scales with form
    b.castT2=(b.castT2||0)+dt;
    const rate=b.form===1?1.6:b.form===2?1.1:0.7;
    if(b.castT2>rate){ b.castT2=0; b.castT=0.3;
      const n=b.form; // more shots per form
      for(let i=0;i<n;i++){
        const ang=Math.atan2((pl.y+20)-b.y, (pl.x+15)-b.x)+(i-(n-1)/2)*0.25;
        st.bossShots.push({x:b.x,y:b.y-40,vx:Math.cos(ang)*260,vy:Math.sin(ang)*260,life:5});
      }
    }
    // vulnerable: stomp the head
    const bw=70,bh=140;
    if(pl.x+pl.w>b.x-bw/2&&pl.x<b.x+bw/2&&pl.y+pl.h>b.y-bh&&pl.y+pl.h<b.y-bh+40&&pl.vy>100){
      b.hp-=1; pl.vy=-460; playSfx('hit',0.7); b.castT=0.4;
      b.form=b.hp>6?1:b.hp>3?2:3;
      if(b.hp<=0){ b.dead=true; bossDefeated(); return; }
    } else if(pl.x+8<b.x+bw/2&&pl.x+pl.w-8>b.x-bw/2&&pl.y+8<b.y&&pl.y+pl.h-6>b.y-bh){
      die(); return;
    }
  }
  // boss shots
  for(const p of st.bossShots){ p.x+=p.vx*dt; p.y+=p.vy*dt; p.life-=dt;
    if(Math.abs(p.x-(pl.x+pl.w/2))<13&&Math.abs(p.y-(pl.y+pl.h/2))<15){ die(); return; } }
  st.bossShots=st.bossShots.filter(p=>p.life>0&&p.y<860&&p.y>-50);

  // ── DEATH checks ──
  // falling trees: trigger from the left, topple RIGHT across the path.
  for(const t of st.treefalls){
    if(t._armed && !t._falling && !t._fallen && pl.x+pl.w/2 > t.triggerX && pl.x+pl.w/2 < t.x-20){
      t._falling=true; t._armed=false; playSfx('treefall',0.7); G.shakeOn!==false&&G.cam.shakeBy(1.0);
    }
    if(t._falling){
      t._ang += dt*3.2;
      if(t._ang>=Math.PI/2*0.9){ t._ang=Math.PI/2*0.9; t._falling=false; t._fallen=true; G.shakeOn!==false&&G.cam.shakeBy(0.6); }
      // crush sweeps to the RIGHT of the pivot (t.x) as the trunk comes down
      const reach = 230*Math.sin(t._ang);
      if(pl.y+pl.h > G.level.groundY-50 && pl.x < t.x+reach && pl.x+pl.w > t.x){ die(); return; }
    }
  }
  if(st.ghostMoanZones){
    G._moanT-=dt;
    if(G._moanT<=0){ playSfx('ghost',0.4); G._moanT=6+Math.random()*8; }
  }
  let dead=false;
  for(const b of st.bats){if(pl.x+6<b.x+14&&pl.x+pl.w-6>b.x-14&&pl.y+6<b.y+14&&pl.y+pl.h-6>b.y-14){dead=true;break;}}
  if(!dead) for(const p of st.projectiles){if(Math.abs(p.x-(pl.x+pl.w/2))<14&&Math.abs(p.y-(pl.y+pl.h/2))<16){dead=true;break;}}
  if(!dead) for(const sp of (G.level.spikes||[])){if(pl.x+6<sp.x+sp.w&&pl.x+pl.w-6>sp.x&&pl.y+pl.h>sp.y&&pl.y+pl.h<sp.y+18){dead=true;break;}}
  if(!dead) for(const sp of st.spikeTimer){if(sp._out>0.4&&pl.x+6<sp.x+sp.w&&pl.x+pl.w-6>sp.x&&pl.y+pl.h>sp.y&&pl.y+pl.h<sp.y+18){dead=true;break;}}
  if(!dead) for(const f of st.fallSpikes){if(pl.x+6<f.x+f.w&&pl.x+pl.w-6>f.x&&pl.y+pl.h>f._y+18&&pl.y<f._y+34){dead=true;break;}}
  if(!dead&&pl.y>880) dead=true;
  if(dead){die();return;}

  // meet cat
  if(st.meet&&!st.meet.done&&Math.abs(pl.x+pl.w/2-st.meet.x)<40){st.meet.done=true;G.hasCat=true;startStory();return;}
  if(G.partner.active) updatePartner(dt);

  // exit
  const ex=G.level.exit;
  if(ex&&pl.x+pl.w>ex.x&&pl.x<ex.x+ex.w&&pl.y+pl.h>ex.y&&pl.y<ex.y+ex.h) nextLevel();

  const look=pl.faceR?80:-80;
  G.cam.follow(pl.x+pl.w/2,pl.y+pl.h/2,look,dt);
}

function updatePartner(dt){
  const pl=G.player,c=G.partner;
  c.trail.push({x:pl.x,y:pl.y});if(c.trail.length>26)c.trail.shift();
  const t=c.trail[0]||{x:pl.x,y:pl.y};const dx=t.x-c.x;c.vx=dx;
  c.x+=dx*Math.min(1,dt*6);c.y+=(t.y-c.y)*Math.min(1,dt*8);
  if(Math.abs(dx)>4)c.faceR=dx>0;
}

function startStory(){
  G.mode='story';G.storyTimer=4.2;stopMusic();
  $('ch-num').textContent='— a meeting —';$('ch-title').textContent='Two Travelers';
  $('ch-desc').textContent='The small black cat steps out of the grass.\nIt looks at the man. The man looks back.\n\nFrom here, they go together.';
  show('chapter-card');$('chapter-card').classList.remove('hidden');hide('hud');
  G.partner.active=true;G.partner.x=G.player.x+50;G.partner.y=G.player.y;G.partner.trail=[];
}

function bossDefeated(){
  G.st.boss.dead=true; G.st.bossShots=[];
  // spawn an exit portal to the win screen
  G.level.exit={x:G.player.x+120,y:G.level.groundY-70,w:48,h:70};
  G.mode='story'; G.storyTimer=4.0; stopMusic();
  $('ch-num').textContent='— the light returns —';
  $('ch-title').textContent='Dawn';
  $('ch-desc').textContent='The shadow breaks apart.\nLight pours back into the worlds.\n\nThe man and the cat walk into it together.';
  show('chapter-card');$('chapter-card').classList.remove('hidden');hide('hud');
  setTimeout(()=>{ G.mode='win';
    $('win-text').textContent=`The light is returned. The worlds wake.\n\nA man who woke alone now walks beside a friend.\n\nDeaths: ${G.deaths}\n\nThank you for playing.`;
    show('win');$('win').classList.remove('hidden');hide('hud');stopMusic();
  },4200);
}

function die(){
  if(!G.player.alive)return;
  G.player.alive=false;G.deaths++;G.shakeOn!==false&&G.cam.shakeBy(1.2);playSfx('hit',0.5);
  $('death-flash').classList.add('on');G.deathTimer=0.6;G.mode='death';
}
function respawn(){
  $('death-flash').classList.remove('on');
  const lv=G.level;
  // reset transient hazards near respawn (full reset is simplest & fair)
  G.st.crumble=(lv.crumble||[]).map(c=>({...c,triggered:false,t:0,gone:false}));
  G.st.fakePlat=(lv.fakePlat||[]).map(f=>({...f,_fell:false,_wobble:false,_t:0}));
  G.st.fallSpikes=(lv.fallSpikes||[]).map(f=>({...f,_y:f.y,_falling:false,_armed:true}));
  G.st.bats=(lv.bats||[]).map(b=>({...b,dir:1,vx:b.spd,diveT:0,diving:false,baseY:b.y}));
  G.st.projectiles=[];
  G.st.bossShots=[];
  G.st.enemies=(lv.enemies||[]).map(e=>({...e,vx:e.spd||0,dir:1,dead:false,baseY:e.y}));
  G.st.treefalls=(lv.treefalls||[]).map(t=>({...t,_falling:false,_fallen:false,_ang:0,_armed:true}));
  // note: boss hp persists across deaths within the fight (fair-ish); keep as is
  const rp=G.respawnPoint;
  G.player.reset(rp.x,rp.y);G.cam.snap(rp.x,rp.y);
  if(G.partner.active){G.partner.x=rp.x-40;G.partner.y=rp.y;G.partner.trail=[];}
  if(lv.music)playMusic(lv.music);
  G.mode='play';
}
function nextLevel(){
  playSfx('door',0.6);
  if(G.levelIndex+1<LEVELS.length)loadLevel(G.levelIndex+1);
  else{stopMusic();G.mode='win';
    $('win-text').textContent=`The man and the cat reached the far side of the worlds.\n\nLight gathered along the way.\nThey are not alone anymore.\n\nDeaths: ${G.deaths}\n\nThank you for playing.`;
    show('win');$('win').classList.remove('hidden');hide('hud');hide('quickbar');}
}
function togglePause(){G.paused=!G.paused;if(G.paused){show('pause');$('pause').classList.remove('hidden');}else hide('pause');}

function render(ts){
  ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#05060a';ctx.fillRect(0,0,canvas.width,canvas.height);
  if(!G.level)return;
  ctx.save();ctx.translate(ox,oy);ctx.scale(sc,sc);
  ctx.beginPath();ctx.rect(0,0,VW,VH);ctx.clip();
  const cam=G.cam;
  drawParallax(ctx,G.level.theme,cam,VW,VH);
  ctx.save();ctx.translate(-cam.x+cam.ox,-cam.y+cam.oy);
  drawWorld(ctx,G.level,G.st,ts);
  if(G.partner.active)drawPartner(ctx,G.partner,ts);
  G.player.draw(ctx);
  ctx.restore();
  const vg=ctx.createRadialGradient(VW/2,VH/2,VH*0.3,VW/2,VH/2,VH*0.78);
  vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,0.5)');
  ctx.fillStyle=vg;ctx.fillRect(0,0,VW,VH);
  ctx.restore();
}

let last=0;
function loop(ts){
  const dt=Math.min((ts-(last||ts))/1000,0.05);last=ts; G._dt=dt;
  if(prologueRunning){ prologueT+=dt; if(prologueT>3.4) advancePrologue(); }
  if(!G.paused){
    if(G.mode==='play')updatePlay(dt,ts);
    else if(G.mode==='chapter'){G.chapterTimer-=dt;if(G.chapterTimer<=0){fade('chapter-card');setTimeout(()=>$('chapter-card').classList.add('hidden'),600);show('hud');$('hud').classList.remove('hidden');$('quickbar').classList.remove('hidden');G.mode='play';}}
    else if(G.mode==='story'){G.storyTimer-=dt;if(G.storyTimer<=0){fade('chapter-card');setTimeout(()=>$('chapter-card').classList.add('hidden'),600);show('hud');$('hud').classList.remove('hidden');$('quickbar').classList.remove('hidden');if(G.level.music)playMusic(G.level.music);G.mode='play';}}
    else if(G.mode==='death'){G.deathTimer-=dt;if(G.deathTimer<=0)respawn();}
  } else if(Input.pauseEdge) togglePause();
  decayInput(dt);render(ts);requestAnimationFrame(loop);
}

async function boot(){
  bindTouch();
  if(matchMedia('(hover:none) and (pointer:coarse)').matches)$('touch').classList.remove('hidden');
  await loadAssets(p=>{$('loadbar').style.width=Math.round(p*100)+'%';$('loadpct').textContent=Math.round(p*100)+'%';});
  fade('loader');setTimeout(()=>{$('loader').classList.add('hidden');show('menu');$('menu').classList.remove('hidden');},600);
  G.mode='menu';playMusic('m_menu',0.3);requestAnimationFrame(loop);
}
$('btn-start').addEventListener('click',()=>{playSfx('click');fade('menu');setTimeout(()=>{$('menu').classList.add('hidden');startPrologue();},600);});
$('btn-help').addEventListener('click',()=>{show('help');$('help').classList.remove('hidden');});
$('btn-help-back').addEventListener('click',()=>hide('help'));
$('btn-replay').addEventListener('click',()=>{hide('win');G.hasCat=false;G.deaths=0;loadLevel(0);});
if($('btn-resume'))$('btn-resume').addEventListener('click',togglePause);
if($('btn-mute'))$('btn-mute').addEventListener('click',()=>{const m=toggleMute();$('btn-mute').textContent=m?'Unmute':'Mute';});

// ── UI helpers + wiring ──
function updateLanternBtn(on){ const b=$('q-lantern'); if(b) b.classList.toggle('active',on); }

function setupToggles(){
  const mk=(id,init,fn)=>{
    const el=$(id); if(!el) return;
    let on=init; el.classList.toggle('on',on); el.textContent=on?'On':'Off';
    el.addEventListener('click',()=>{ on=!on; el.classList.toggle('on',on); el.textContent=on?'On':'Off'; fn(on); playSfx('click',0.4); });
  };
  mk('tg-music',true,on=>setMusicEnabled(on));
  mk('tg-sfx',true,on=>setSfxEnabled(on));
  mk('tg-dark',true,on=>setDark(on));
  mk('tg-shake',true,on=>{G.shakeOn=on;});
  mk('tg-touch',false,on=>{ $('touch').classList.toggle('hidden',!on); });
}
G.shakeOn=true;

// quickbar
if($('q-lantern')) $('q-lantern').addEventListener('click',()=>{const on=toggleLantern();updateLanternBtn(on);playSfx('lever',0.3);});
if($('q-pause')) $('q-pause').addEventListener('click',()=>togglePause());
if($('btn-quit')) $('btn-quit').addEventListener('click',()=>{ G.paused=false; hide('pause'); hide('hud'); hide('quickbar'); stopMusic(); show('menu'); $('menu').classList.remove('hidden'); G.mode='menu'; playMusic('m_menu',0.3); });


// ── Cinematic prologue (LIMBO-style fading lines) ──
const PROLOGUE=[
  "There was a world, once, full of light.",
  "Then the light was taken.",
  "A shadow drank the glow from every hill and hollow.",
  "Far below, a man opens his eyes in the dark.",
  "He does not know why he wakes.",
  "Only that something small is waiting in the grass.",
];
let prologueIdx=0, prologueT=0, prologueRunning=false;
function startPrologue(){
  prologueRunning=true; prologueIdx=0; prologueT=0;
  show('prologue'); $('prologue').classList.remove('hidden');
  showPrologueLine();
}
function showPrologueLine(){
  const el=$('prologue-text');
  el.classList.remove('show');
  setTimeout(()=>{ el.textContent=PROLOGUE[prologueIdx]; el.classList.add('show'); },120);
  prologueT=0;
}
function advancePrologue(){
  if(!prologueRunning) return;
  prologueIdx++;
  if(prologueIdx>=PROLOGUE.length){ endPrologue(); return; }
  showPrologueLine();
}
function endPrologue(){
  prologueRunning=false;
  $('prologue-text').classList.remove('show');
  fade('prologue'); setTimeout(()=>$('prologue').classList.add('hidden'),700);
  G.hasCat=false; G.deaths=0;
  setTimeout(()=>loadLevel(0), 700);
}
$('prologue').addEventListener('click',advancePrologue);
window.addEventListener('keydown',e=>{ if(prologueRunning) advancePrologue(); });


setupToggles();
updateLanternBtn(true);
boot();
window.__loadLevel=loadLevel;window.__setCat=()=>{G.hasCat=true;};
window.__tp=(x)=>{G.player.x=x;G.cam.snap(x,G.player.y);};
window.__killBoss=()=>{if(G.st&&G.st.boss){G.st.boss.hp=0;G.st.boss.dead=true;bossDefeated();}};
